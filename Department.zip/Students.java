package com.mycompany.universitymanagmentsystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Marium
 */
import java.util.Scanner;

public class Students {
    private String name;
    private int rollNumber;
    private String department;

    // Default constructor
    public Students() {
        this.name = "Unknown";
        this.rollNumber = 0;
        this.department = "Unknown";
    }

    // Parameterized constructor
    public Students(String name, String department, int rollNumber) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.department = department;
    }

    // Copy constructor
    public Students(Students s) {
        this.name = s.name;
        this.rollNumber = s.rollNumber;
        this.department = s.department;
    }

    // Display function
    public void displayStudent() {
        System.out.println("Student name: " + name);
        System.out.println("Student roll number: " + rollNumber);
        System.out.println("Student department: " + department);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter department name:");
        String department = input.nextLine();
        
        System.out.println("Enter the student name:");
        String name1 = input.nextLine();
        System.out.println("Enter student roll number:");
        int rollNumber1 = input.nextInt();
        input.nextLine(); // To consume the leftover newline
        
        Students student1 = new Students(name1, department, rollNumber1);
        
        System.out.println("Enter the student name:");
        String name2 = input.nextLine();
        System.out.println("Enter student roll number:");
        int rollNumber2 = input.nextInt();
        
        Students student2 = new Students(name2, department, rollNumber2);

        student1.displayStudent();
        student2.displayStudent();
        
        input.close();
    }
}
