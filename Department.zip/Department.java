package com.mycompany.universitymanagmentsystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Marium
 */
import java.util.Scanner;

public class Department {
    private String deptName;
    private String deptHead;

    // Default constructor
    public Department() {
        this.deptName = "Unknown";
        this.deptHead = "Unknown";
    }

    // Parameterized constructor
    public Department(String deptName, String deptHead) {
        this.deptName = deptName;
        this.deptHead = deptHead;
    }

    // Copy constructor
    public Department(Department d) {
        this.deptName = d.deptName;
        this.deptHead = d.deptHead;
    }

    // Display function
    public void displayDepartment() {
        System.out.println("Department name: " + deptName);
        System.out.println("Department head: " + deptHead);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the department name:");
        String deptName = input.nextLine();
        System.out.println("Enter the department head:");
        String deptHead = input.nextLine();
        
        Department department = new Department(deptName, deptHead);
        department.displayDepartment();
        
        input.close();
    }
}
