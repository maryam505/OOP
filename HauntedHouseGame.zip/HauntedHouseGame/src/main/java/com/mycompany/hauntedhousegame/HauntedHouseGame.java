/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hauntedhousegame;

/**
 *
 * @author Marium
 */
import java.util.Scanner;
public class HauntedHouseGame {
    public static void main(String[] args) {
       
        String[] mysteryWords = {"GHOST", "VAMPIRE", "ZOMBIE"};
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Haunted House Escape!");
        System.out.println("Solve the mystery words to escape...\n");

        int score = 0;

       
        for (int i = 0; i < mysteryWords.length; i++) {
            System.out.println("Room " + (i + 1) + ": Guess the mystery word!");
            String hint = mysteryWords[i].substring(0, 1); 
            System.out.println("Hint: The word starts with '" + hint + "'");

            String guess;
            boolean guessedCorrectly = false;

            do {
                System.out.print("Your guess: ");
                guess = scanner.nextLine().toUpperCase(); 
                if (guess.equals(mysteryWords[i])) {
                    guessedCorrectly = true;
                    System.out.println("Correct! Moving to the next room...\n");
                    score++;
                } else {
                    System.out.println("Wrong guess! Try again.");
                }
            } while (!guessedCorrectly);
        }

        System.out.println("Game Over! Your Score: " + score + "/" + mysteryWords.length);
        System.out.println("Congratulations! You escaped the Haunted House!");

        scanner.close();
    }
}


  